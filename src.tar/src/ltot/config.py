from dataclasses import dataclass

@dataclass
class LToTParams:
    pass
